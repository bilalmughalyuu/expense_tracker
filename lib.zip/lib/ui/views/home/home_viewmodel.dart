import 'dart:convert';
import 'package:expense_tracker/Models/ExpenseModel.dart';
import 'package:expense_tracker/app/app.router.dart';
import 'package:stacked/stacked.dart';
import 'package:stacked_services/stacked_services.dart';
import '../../../app/app.locator.dart';
import '../../../utils/DBHelper.dart';

class HomeViewModel extends BaseViewModel {

  final _navigationService = locator<NavigationService>();

  List<ExpenseModel> expensesList = [];


  getAllExpenses() async {
    final dbHelper = await DBHelper.init();

    Map<String, String> abc = await dbHelper.getAllExpenses();

    List<String> encodedExpenses = abc.values.toList();
    for (var expense in encodedExpenses) {
      ExpenseModel expenseModel = ExpenseModel.fromJson(jsonDecode(expense));
      expensesList.add(expenseModel);
    }

    notifyListeners();
  }

  navigateToAddExpense() {
    _navigationService.navigateToAddExpenseView();
  }
}
