import 'package:expense_tracker/Models/UserModel.dart';
import 'package:expense_tracker/utils/SharedPref.dart';
import 'package:stacked/stacked.dart';
import 'package:expense_tracker/app/app.locator.dart';
import 'package:expense_tracker/app/app.router.dart';
import 'package:stacked_services/stacked_services.dart';

class StartupViewModel extends BaseViewModel {
  final _navigationService = locator<NavigationService>();

  Future runStartupLogic() async {
    UserModel? userModel = await SharedPref().getUserData();

    if (userModel != null) {
      DateTime expiryTime = userModel.timeStamp!.add(const Duration(seconds: 1000));

      if (DateTime.now().isAfter(expiryTime)) {
        // await SharedPref().clearUserData();
        _navigationService.replaceWithLoginView();
      } else {
        _navigationService.replaceWithHomeView();
      }
    } else {
      _navigationService.replaceWithLoginView();
    }
  }
}
