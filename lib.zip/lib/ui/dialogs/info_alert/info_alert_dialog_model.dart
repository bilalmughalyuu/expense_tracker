import 'package:stacked/stacked.dart';

class InfoAlertDialogModel extends BaseViewModel {}
