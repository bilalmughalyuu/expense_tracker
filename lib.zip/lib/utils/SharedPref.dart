import 'dart:convert';
import 'package:expense_tracker/Models/UserModel.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SharedPref {
  static const USER_DATA = 'userData';

  Future<void> saveUserData(UserModel data) async {
    final prefs = await SharedPreferences.getInstance();
    prefs.setString(USER_DATA, jsonEncode(data));
  }

  Future<UserModel?> getUserData() async {
    final prefs = await SharedPreferences.getInstance();
    if (prefs.containsKey(USER_DATA)) {
      return userModelFromJson(prefs.getString(USER_DATA)!);
    }
    return null;
  }

  Future<bool> clearUserData() async {
    final prefs = await SharedPreferences.getInstance();
    if (prefs.containsKey("userData")) {
      await prefs.remove("userData");
      return true;
    }
    return false;
  }
}
