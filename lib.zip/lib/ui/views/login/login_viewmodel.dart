import 'package:expense_tracker/app/app.router.dart';
import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';
import 'package:stacked_services/stacked_services.dart';

import '../../../Models/UserModel.dart';
import '../../../app/app.bottomsheets.dart';
import '../../../app/app.dialogs.dart';
import '../../../app/app.locator.dart';
import '../../../utils/SharedPref.dart';
import '../../common/app_strings.dart';

class LoginViewModel extends BaseViewModel {
  final _dialogService = locator<DialogService>();
  final _bottomSheetService = locator<BottomSheetService>();
  final _navigationService = locator<NavigationService>();

  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();

  void showDialog() {
    _dialogService.showCustomDialog(
      variant: DialogType.infoAlert,
      title: 'Stacked Rocks!',
      description: 'Give stacked stars on Github',
    );
  }

  void showBottomSheet() {
    _bottomSheetService.showCustomSheet(
      variant: BottomSheetType.notice,
      title: ksHomeBottomSheetTitle,
      description: ksHomeBottomSheetDescription,
    );
  }

  void login() async {
    print("Hello");
    UserModel? userModel = await SharedPref().getUserData();
    if (userModel != null) {
      if (emailController.text == userModel.email &&
          passwordController.text == userModel.password) {
        _navigationService.replaceWithHomeView();
      } else {
        print(userModel.email);
        print(userModel.password);
        print(emailController.text);
        print(passwordController.text);
      }
    } else {
      print("Wrong email or password");
    }
  }

  void navigateToSignUp() {
    _navigationService.replaceWithSignupView();
  }
}
