import 'package:expense_tracker/Models/UserModel.dart';
import 'package:expense_tracker/app/app.router.dart';
import 'package:expense_tracker/utils/SharedPref.dart';
import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';
import 'package:stacked_services/stacked_services.dart';

import '../../../app/app.locator.dart';

class SignupViewModel extends BaseViewModel {
  final _navigationService = locator<NavigationService>();

  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();

  void navigateToLogin() {
    _navigationService.replaceWithHomeView();
  }

  createAccount() async {
    UserModel userModel = UserModel(
        email: emailController.text.trim(),
        password: passwordController.text.trim(),
        timeStamp: DateTime.now()
    );
    await SharedPref().saveUserData(userModel);
    _navigationService.replaceWithHomeView();
  }
}
