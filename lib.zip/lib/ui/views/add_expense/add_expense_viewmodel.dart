import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';
import 'package:uuid/uuid.dart';

import '../../../Models/ExpenseModel.dart';
import '../../../utils/DBHelper.dart';

class AddExpenseViewModel extends BaseViewModel {
  TextEditingController expenseTitle = TextEditingController();
  TextEditingController expenseAmount = TextEditingController();

  List<ExpenseModel> expensesList = [];

  List<String> categories = [
    "Food",
    "Travel",
    "Shopping",
    "Entertainment",
    "Health",
    "Education",
    "Bills",
    "Other"
  ];

  String? selectedCategory;

  selectCategory(String? category) {
    selectedCategory = category;
    notifyListeners();
  }

  DateTime? _selectedDate;

  DateTime? get selectedDate => _selectedDate;

  void setSelectedDate(DateTime date) {
    _selectedDate = date;
    notifyListeners();
  }

  addExpense() async {
    final dbHelper = await DBHelper.init();

    var uuid = Uuid();

    String id = uuid.v4();

    ExpenseModel expenseModel = ExpenseModel(
        id: id,
        title: expenseTitle.text.trim(),
        amount: expenseAmount.text.trim(),
        category: selectedCategory,
        timeStamp: DateTime.now());

    await dbHelper.addExpense(id, jsonEncode(expenseModel));
  }

  getAllExpenses() async {
    final dbHelper = await DBHelper.init();

    Map<String, String> abc = await dbHelper.getAllExpenses();

    List<String> encodedExpenses = abc.values.toList();
    for (var expense in encodedExpenses) {
      ExpenseModel expenseModel = ExpenseModel.fromJson(jsonDecode(expense));
      expensesList.add(expenseModel);
    }

    notifyListeners();
  }
}
