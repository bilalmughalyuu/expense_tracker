import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';

import '../../common/ui_helpers.dart';
import 'add_expense_viewmodel.dart';

class AddExpenseView extends StackedView<AddExpenseViewModel> {
  const AddExpenseView({Key? key}) : super(key: key);

  @override
  Widget builder(
    BuildContext context,
    AddExpenseViewModel viewModel,
    Widget? child,
  ) {
    return Scaffold(
      backgroundColor: Theme.of(context).colorScheme.background,
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16.0),
        child: SafeArea(
          child: Column(
            children: [
              TextFormField(
                controller: viewModel.expenseTitle,
                decoration: InputDecoration(
                  labelText: 'Enter title',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.email),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter a email';
                  }
                  return null;
                },
              ),
              verticalSpaceMedium,
              TextFormField(
                controller: viewModel.expenseAmount,
                decoration: InputDecoration(
                  labelText: 'Enter Amount',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.email),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter a email';
                  }
                  return null;
                },
              ),
              verticalSpaceMedium,
              DropdownButton<String>(
                hint: Text("Select an item"),
                value: viewModel.selectedCategory,
                items: viewModel.categories.map((String item) {
                  return DropdownMenuItem<String>(
                    value: item,
                    child: Text(item),
                  );
                }).toList(),
                onChanged: (String? newValue) {
                  viewModel.selectCategory(newValue);
                },
              ),
              verticalSpaceMedium,
              GestureDetector(
                onTap: () async {
                  DateTime? pickedDate = await showDatePicker(
                    context: context,
                    initialDate: viewModel.selectedDate ?? DateTime.now(),
                    firstDate: DateTime(2000),
                    lastDate: DateTime(2101),
                  );

                  if (pickedDate != null) {
                    viewModel.setSelectedDate(pickedDate);
                  }
                },
                child: Container(
                  width: double.infinity,
                  height: 40,
                  decoration:
                  BoxDecoration(borderRadius: BorderRadius.circular(8)),
                  child: Center(
                    child: Text("Pick a date"),
                  ),
                ),
              ),
              verticalSpaceMedium,
              GestureDetector(
                onTap: () {
                  viewModel.addExpense();
                },
                child: Container(
                  width: double.infinity,
                  height: 40,
                  decoration:
                  BoxDecoration(borderRadius: BorderRadius.circular(8)),
                  child: const Center(
                    child: Text("Add Expense"),
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  @override
  AddExpenseViewModel viewModelBuilder(
    BuildContext context,
  ) =>
      AddExpenseViewModel();
}
